# ⚡ EtsyFlow — AI-Powered Etsy Automation Platform

**13 AI modules. One dashboard. Path to $5K/week.**

---

## 🚀 Deploy in 10 Minutes (Free)

### Step 1 — Get Your Anthropic API Key
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up / log in → click **API Keys** → **Create Key**
3. Copy the key (starts with `sk-ant-...`)
4. Add $5 credit in Billing — this lasts weeks at normal usage

### Step 2 — Upload to GitHub
1. Go to [github.com/new](https://github.com/new)
2. Name the repo `etsyflow`, set to **Private**, click **Create**
3. Upload all the files from this ZIP (drag and drop works)
4. Click **Commit changes**

### Step 3 — Deploy on Vercel (Free)
1. Go to [vercel.com](https://vercel.com) → **Sign up with GitHub** (free)
2. Click **Add New Project** → select your `etsyflow` repo → click **Import**
3. Before clicking Deploy, click **Environment Variables** and add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from Step 1
4. Click **Deploy** → wait ~2 minutes
5. 🎉 Your app is live at `https://etsyflow-[yourname].vercel.app`

---

## 💻 Run Locally (Optional)

```bash
# Install dependencies
npm install

# Create your local env file
cp .env.example .env.local
# Then edit .env.local and add your real API key

# Start the dev server
npm run dev

# Open http://localhost:3000
```

---

## 📦 What's Inside

| Module | What It Does |
|--------|-------------|
| ⚡ Launch Checklist | Step-by-step guide from zero to live |
| ◈ Product Sourcing | Find 8 high-margin products in any niche |
| ◉ Listing Generator | SEO title, 13 tags, full description |
| ⌖ Keyword Research | High-volume, low-competition keywords |
| ◆ Marketing Engine | 2-week content plans for any platform |
| ✉ Email Sequences | 5 complete email flows |
| ◎ Fulfillment Msgs | Every customer message template |
| ◑ Ads Calculator | ROI model + AI ad strategy |
| ⬡ Profit Tracker | Real margin math after all Etsy fees |
| ◭ Competitor Analyzer | Find weaknesses, build attack plan |
| ❋ Seasonal Calendar | Monthly prep plans, 6 weeks early |
| ▲ Scale Advisor | Personalized strategy to $5K/week |
| ◐ $5K Roadmap | 12-week milestone plan |

---

## 💰 Cost to Run

| Service | Cost |
|---------|------|
| Vercel hosting | **Free** |
| Anthropic API | ~$5–30/month (pay per use) |
| Printify (POD) | **Free** (cost deducted per order) |
| Mailchimp | **Free** up to 500 subscribers |
| Pinterest Business | **Free** |
| **Total to launch** | **~$10–15** |

---

## 🔒 Security

- Your API key is stored as a Vercel environment variable — never in code
- All AI calls go through `/api/claude` (server-side) — the key is never exposed to the browser
- The `.env.local` file is in `.gitignore` — it will never be committed to GitHub

---

## 📈 The $5K/Week Path

```
Week 1-2:  Launch 10 listings → $0 to $500
Week 3-4:  Find top 3 sellers, add variations → $500 to $1,200
Week 5-6:  Scale ads on winners → $1,200 to $2,500
Week 7-8:  Seasonal + 2nd niche → $2,500 to $4,000
Week 9-12: Full automation → $4,000 to $5,000+
```

**The formula:** 10 listings × $40 avg × 3 sales/day = $1,200/day

---

Built with Next.js + Claude AI (Anthropic)

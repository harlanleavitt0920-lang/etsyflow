import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { system, message, maxTokens = 1000 } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({
      error: "ANTHROPIC_API_KEY not configured. Add it to your Vercel environment variables.",
    });
  }

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: maxTokens,
      system: system || "You are a helpful Etsy business assistant.",
      messages: [{ role: "user", content: message }],
    });

    return res.status(200).json({
      text: response.content[0]?.text || "No response received.",
    });
  } catch (error) {
    console.error("Anthropic API error:", error);
    return res.status(500).json({
      error: error.message || "Failed to get AI response",
    });
  }
}

import { useState, useEffect, useRef } from "react";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

const MODULES = [
  { id:"launch",     icon:"⚡", label:"Launch Checklist",   color:"#00F5FF", group:"START HERE" },
  { id:"sourcing",   icon:"◈",  label:"Product Sourcing",    color:"#F4A261", group:"CORE TOOLS" },
  { id:"listings",   icon:"◉",  label:"Listing Generator",   color:"#2EC4B6", group:"CORE TOOLS" },
  { id:"keywords",   icon:"⌖",  label:"Keyword Research",    color:"#4CC9F0", group:"CORE TOOLS" },
  { id:"marketing",  icon:"◆",  label:"Marketing Engine",    color:"#E76F51", group:"CORE TOOLS" },
  { id:"email",      icon:"✉",  label:"Email Sequences",     color:"#F72585", group:"CORE TOOLS" },
  { id:"fulfillment",icon:"◎",  label:"Fulfillment Msgs",    color:"#A8DADC", group:"CORE TOOLS" },
  { id:"ads",        icon:"◑",  label:"Ads Calculator",      color:"#FF6B9D", group:"ANALYTICS" },
  { id:"profit",     icon:"⬡",  label:"Profit Tracker",      color:"#06D6A0", group:"ANALYTICS" },
  { id:"competitor", icon:"◭",  label:"Competitor Analyzer", color:"#BD93F9", group:"ANALYTICS" },
  { id:"seasonal",   icon:"❋",  label:"Seasonal Calendar",   color:"#FF9A3C", group:"ANALYTICS" },
  { id:"scale",      icon:"▲",  label:"Scale Advisor",       color:"#FFD166", group:"GROWTH" },
  { id:"roadmap",    icon:"◐",  label:"$5K Roadmap",         color:"#C77DFF", group:"GROWTH" },
];

const ROADMAP_DATA = [
  { week:"Week 1–2",  goal:"$0 → $500",      action:"Launch 10 listings, Etsy Ads $3/day, 5 Pinterest pins/day", status:"start" },
  { week:"Week 3–4",  goal:"$500 → $1,200",  action:"Top 3 sellers found, add variations, 10 more listings", status:"build" },
  { week:"Week 5–6",  goal:"$1,200 → $2,500",action:"Scale ads on winners, build email list, add cross-sells", status:"grow" },
  { week:"Week 7–8",  goal:"$2,500 → $4,000",action:"Seasonal products, automate reviews, expand 2nd niche", status:"scale" },
  { week:"Week 9–12", goal:"$4,000 → $5K+",  action:"Full POD automation, VA for fulfillment, reinvest 20% into ads", status:"peak" },
];

const SEASONS = [
  { month:"January",   icon:"❄️", events:["New Year","Winter clearance"],      niches:["organization","planners","self-care","winter decor"] },
  { month:"February",  icon:"💝", events:["Valentine's Day"],                  niches:["couples gifts","heart prints","love quotes","jewelry"] },
  { month:"March",     icon:"🍀", events:["St. Patrick's","Spring"],           niches:["green decor","spring wreaths","St. Pat's shirts"] },
  { month:"April",     icon:"🐣", events:["Easter","Earth Day"],               niches:["Easter baskets","spring floral","eco products"] },
  { month:"May",       icon:"🌸", events:["Mother's Day","Graduation"],        niches:["mom gifts","personalized jewelry","grad gifts"] },
  { month:"June",      icon:"☀️", events:["Father's Day","Wedding season"],    niches:["dad gifts","wedding favors","summer decor"] },
  { month:"July",      icon:"🎆", events:["4th of July","Summer peak"],        niches:["patriotic","beach","outdoor","Americana"] },
  { month:"August",    icon:"🎒", events:["Back to School"],                   niches:["teacher gifts","school supplies","dorm decor"] },
  { month:"September", icon:"🍂", events:["Fall begins","Labor Day"],          niches:["fall decor","pumpkin","cozy home","harvest"] },
  { month:"October",   icon:"🎃", events:["Halloween","Fall peak"],            niches:["Halloween prints","spooky decor","witch aesthetic"] },
  { month:"November",  icon:"🦃", events:["Thanksgiving","Black Friday"],      niches:["thankful prints","holiday prep","gift bundles"] },
  { month:"December",  icon:"🎄", events:["Christmas","Hanukkah","NYE"],       niches:["ornaments","stockings","holiday cards","wrap"] },
];

// ─── AI CALL (hits our secure server-side route) ──────────────────────────────

async function callClaude(system, message, maxTokens = 1000) {
  const res = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system, message, maxTokens }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.text;
}

// ─── SHARED COMPONENTS ────────────────────────────────────────────────────────

function TypewriterText({ text }) {
  const [shown, setShown] = useState(""); const [done, setDone] = useState(false);
  useEffect(() => {
    setShown(""); setDone(false); if (!text) return;
    let i = 0;
    const iv = setInterval(() => { setShown(text.slice(0,++i)); if(i>=text.length){clearInterval(iv);setDone(true);} }, 7);
    return () => clearInterval(iv);
  }, [text]);
  return <span style={{whiteSpace:"pre-wrap"}}>{shown}{!done&&<span style={{animation:"blink 1s infinite",color:"#F4A261"}}>▌</span>}</span>;
}

function ResultBox({ result, loading, error }) {
  if (!result && !loading && !error) return null;
  return (
    <div style={{marginTop:20,background:"rgba(255,255,255,0.03)",border:`1px solid ${error?"rgba(255,107,107,0.3)":"rgba(255,255,255,0.1)"}`,borderRadius:12,padding:20,fontFamily:"'DM Mono',monospace",fontSize:13,lineHeight:1.8,color:error?"#FF6B6B":"#e0e0e0",minHeight:80}}>
      {loading
        ? <div style={{display:"flex",alignItems:"center",gap:12,color:"#F4A261"}}><span style={{animation:"spin 1s linear infinite",display:"inline-block"}}>⟳</span><span>AI is thinking…</span></div>
        : error ? <span>⚠ {error}</span>
        : <TypewriterText text={result}/>}
    </div>
  );
}

function Chip({ label, active, color, onClick }) {
  return <button onClick={onClick} style={{padding:"6px 14px",borderRadius:20,cursor:"pointer",border:`1px solid ${active?color:"rgba(255,255,255,0.15)"}`,background:active?color:"transparent",color:active?"#0d0d0d":"#aaa",fontFamily:"'DM Mono',monospace",fontSize:12,fontWeight:active?"700":"400"}}>{label}</button>;
}

function StatCard({ label, value, sub, color }) {
  return (
    <div style={{background:`${color}10`,border:`1px solid ${color}30`,borderRadius:12,padding:"14px 18px",flex:1,minWidth:100}}>
      <div style={{color:"#777",fontSize:10,letterSpacing:"1px",fontFamily:"'DM Mono',monospace",marginBottom:5}}>{label}</div>
      <div style={{color,fontSize:20,fontFamily:"'DM Serif Display',serif"}}>{value}</div>
      {sub&&<div style={{color:"#555",fontSize:11,fontFamily:"'DM Mono',monospace",marginTop:3}}>{sub}</div>}
    </div>
  );
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  return <button onClick={()=>{navigator.clipboard?.writeText(text).catch(()=>{});setCopied(true);setTimeout(()=>setCopied(false),2000);}} style={{padding:"4px 12px",borderRadius:6,border:"1px solid rgba(255,255,255,0.15)",background:"transparent",color:copied?"#06D6A0":"#888",fontFamily:"'DM Mono',monospace",fontSize:11,cursor:"pointer"}}>{copied?"✓ Copied":"Copy"}</button>;
}

function useAI() {
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const run = async (sys, msg, maxTokens) => {
    setLoading(true); setResult(""); setError("");
    try { const r = await callClaude(sys, msg, maxTokens); setResult(r); }
    catch(e) { setError(e.message); }
    finally { setLoading(false); }
  };
  return { result, loading, error, run };
}

const S = {
  title:  {fontFamily:"'DM Serif Display',serif",fontSize:22,color:"#fff",margin:"0 0 8px 0",fontWeight:"400"},
  desc:   {fontFamily:"'DM Mono',monospace",fontSize:13,color:"#888",margin:"0 0 20px 0",lineHeight:1.6},
  input:  {flex:1,minWidth:200,background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.15)",borderRadius:10,padding:"11px 15px",color:"#fff",fontFamily:"'DM Mono',monospace",fontSize:13},
  btn:    (bg,fg="#0d0d0d")=>({padding:"11px 20px",borderRadius:10,border:"none",cursor:"pointer",fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:"700",color:fg,background:bg,whiteSpace:"nowrap"}),
  card:   {background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:12,padding:20},
  label:  {color:"#777",fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:"0.8px",marginBottom:5,display:"block"},
  row:    {display:"flex",gap:10,flexWrap:"wrap"},
};

// ─── LAUNCH CHECKLIST (UPDATED WITH DEPLOY STEPS) ─────────────────────────────

function LaunchPanel() {
  const [checks, setChecks] = useState({});
  const { result, loading, error, run } = useAI();
  const [situation, setSituation] = useState("");

  const CHECKLIST = [
    { group:"🚀 STEP 1 — DEPLOY THIS APP (Do This First)", items:[
      { id:"d1", text:"Download the EtsyFlow ZIP from the download link above this checklist", cost:"Free" },
      { id:"d2", text:"Go to github.com → New repository → name it 'etsyflow' → upload all files", link:"https://github.com/new", cost:"Free" },
      { id:"d3", text:"Go to vercel.com → Sign up free with GitHub → 'Add New Project' → import your etsyflow repo", link:"https://vercel.com/new", cost:"Free" },
      { id:"d4", text:"In Vercel project settings → Environment Variables → add: ANTHROPIC_API_KEY = your key", cost:"Free" },
      { id:"d5", text:"Get your API key at console.anthropic.com → API Keys → Create Key → copy it", link:"https://console.anthropic.com/settings/keys", cost:"~$5 credit" },
      { id:"d6", text:"Click 'Deploy' in Vercel → wait 2 min → your app is live at yourname.vercel.app 🎉", cost:"Free" },
    ]},
    { group:"🏪 STEP 2 — ETSY SHOP SETUP", items:[
      { id:"e1", text:"Create Etsy seller account at etsy.com/sell", link:"https://www.etsy.com/sell", cost:"Free" },
      { id:"e2", text:"Choose shop name (brandable, niche-relevant, check it's not trademarked)", cost:"Free" },
      { id:"e3", text:"Design shop banner + logo in Canva (2000×500px)", link:"https://canva.com", cost:"Free" },
      { id:"e4", text:"Write shop About section using AI — describe your story in 150-300 words", cost:"Free" },
      { id:"e5", text:"Set shipping, return & exchange policies (use Fulfillment module for wording)", cost:"Free" },
      { id:"e6", text:"Connect bank account for payouts", cost:"Free" },
    ]},
    { group:"🖨 STEP 3 — PRINT-ON-DEMAND SETUP", items:[
      { id:"p1", text:"Create free Printify account at printify.com", link:"https://printify.com", cost:"Free" },
      { id:"p2", text:"Connect Printify → your Etsy shop (Settings → Integrations → Etsy)", cost:"Free" },
      { id:"p3", text:"Browse Printify catalog → choose 3 products to start (mugs, totes, prints)", cost:"Free" },
      { id:"p4", text:"Create product mockups using Printify Mockup Generator + Canva", cost:"Free" },
    ]},
    { group:"📦 STEP 4 — FIRST 10 LISTINGS", items:[
      { id:"l1", text:"Use ◈ Product Sourcing → type your niche → pick 10 winners from AI output", cost:"This app" },
      { id:"l2", text:"Use ⌖ Keyword Research → get tags + keywords for each product", cost:"This app" },
      { id:"l3", text:"Use ◉ Listing Generator → write all 10 listings → copy into Etsy", cost:"This app" },
      { id:"l4", text:"Upload 5-10 mockup photos per listing (mix lifestyle + flat lay + close-up)", cost:"Free (Canva)" },
      { id:"l5", text:"Use ⬡ Profit Tracker → set prices at 20-30% above cost + fees", cost:"This app" },
    ]},
    { group:"📣 STEP 5 — MARKETING SETUP", items:[
      { id:"m1", text:"Create Pinterest Business account → connect to Etsy shop", link:"https://business.pinterest.com", cost:"Free" },
      { id:"m2", text:"Use ◆ Marketing Engine → generate 30 Pinterest pin captions for your niche", cost:"This app" },
      { id:"m3", text:"Create Mailchimp free account → set up list", link:"https://mailchimp.com", cost:"Free" },
      { id:"m4", text:"Use ✉ Email Sequences → build Welcome Series → load into Mailchimp", cost:"This app" },
    ]},
    { group:"🎯 STEP 6 — LAUNCH DAY", items:[
      { id:"go1", text:"Publish all 10 listings on Etsy (set status to Active)", cost:"$2 total ($0.20 each)" },
      { id:"go2", text:"Post first 5 Pinterest pins with your listing links", cost:"Free" },
      { id:"go3", text:"Enable Etsy Ads at $3/day → use ◑ Ads Calculator to model your ROI first", cost:"$3/day" },
      { id:"go4", text:"Bookmark your Etsy Stats dashboard — check it every morning", cost:"Free" },
      { id:"go5", text:"Come back to ▲ Scale Advisor weekly — paste your numbers, get your next move", cost:"This app" },
    ]},
  ];

  const total = CHECKLIST.flatMap(g=>g.items).length;
  const done  = Object.values(checks).filter(Boolean).length;
  const pct   = Math.round((done/total)*100);
  const statusColor = pct===100?"#06D6A0":pct>60?"#FFD166":pct>30?"#F4A261":"#FF6B9D";
  const toggle = id => setChecks(p=>({...p,[id]:!p[id]}));

  return (
    <div>
      <h3 style={S.title}>⚡ Launch Checklist</h3>
      <p style={S.desc}>Your complete step-by-step guide from zero to live. Start at Step 1 — deploy the app first, then work through each group in order.</p>

      {/* Progress bar */}
      <div style={{...S.card,marginBottom:20,display:"flex",alignItems:"center",gap:20}}>
        <div style={{flex:1}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <span style={{color:"#fff",fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:"700"}}>Launch Progress</span>
            <span style={{color:statusColor,fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:"700"}}>{done}/{total} complete · {pct}%</span>
          </div>
          <div style={{height:6,background:"rgba(255,255,255,0.08)",borderRadius:3,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${pct}%`,background:statusColor,borderRadius:3,transition:"width 0.4s ease"}}/>
          </div>
        </div>
        {pct===100&&<div style={{fontSize:24}}>🎉</div>}
      </div>

      {/* Cost summary banner */}
      <div style={{...S.card,marginBottom:20,background:"linear-gradient(135deg,rgba(0,245,255,0.06),rgba(6,214,160,0.06))",borderColor:"rgba(0,245,255,0.2)",display:"flex",gap:20,flexWrap:"wrap"}}>
        <div style={{fontFamily:"'DM Mono',monospace"}}>
          <div style={{color:"#00F5FF",fontSize:10,letterSpacing:"1px",marginBottom:6}}>TOTAL STARTUP COST</div>
          <div style={{color:"#fff",fontSize:22,fontFamily:"'DM Serif Display',serif"}}>~$10–15</div>
          <div style={{color:"#555",fontSize:11,marginTop:3}}>then ~$5/mo AI + $3/day optional ads</div>
        </div>
        <div style={{borderLeft:"1px solid rgba(255,255,255,0.08)",paddingLeft:20,fontFamily:"'DM Mono',monospace"}}>
          <div style={{color:"#06D6A0",fontSize:10,letterSpacing:"1px",marginBottom:6}}>FREE ITEMS IN THIS LIST</div>
          <div style={{color:"#fff",fontSize:13,lineHeight:1.8}}>Vercel hosting · Printify POD · Mailchimp · Pinterest · Canva · Etsy account</div>
        </div>
      </div>

      {/* Checklist groups */}
      {CHECKLIST.map(group=>(
        <div key={group.group} style={{marginBottom:24}}>
          <div style={{color:"#777",fontSize:11,fontFamily:"'DM Mono',monospace",letterSpacing:"1px",marginBottom:10,paddingBottom:8,borderBottom:"1px solid rgba(255,255,255,0.06)"}}>{group.group}</div>
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {group.items.map(item=>(
              <div key={item.id} onClick={()=>toggle(item.id)} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 14px",background:checks[item.id]?"rgba(6,214,160,0.05)":"rgba(255,255,255,0.02)",border:`1px solid ${checks[item.id]?"rgba(6,214,160,0.2)":"rgba(255,255,255,0.06)"}`,borderRadius:9,cursor:"pointer",transition:"all 0.12s"}}>
                <div style={{width:18,height:18,borderRadius:4,border:`2px solid ${checks[item.id]?"#06D6A0":"rgba(255,255,255,0.2)"}`,background:checks[item.id]?"#06D6A0":"transparent",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,color:"#0d0d0d",fontWeight:"700"}}>
                  {checks[item.id]?"✓":""}
                </div>
                <span style={{flex:1,color:checks[item.id]?"#555":"#ccc",fontFamily:"'DM Mono',monospace",fontSize:12,textDecoration:checks[item.id]?"line-through":"none",lineHeight:1.5}}>{item.text}</span>
                <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
                  {item.cost&&<span style={{color:item.cost==="Free"?"#444":"#F4A261",fontSize:10,fontFamily:"'DM Mono',monospace",whiteSpace:"nowrap"}}>{item.cost}</span>}
                  {item.link&&<a href={item.link} target="_blank" rel="noreferrer" onClick={e=>e.stopPropagation()} style={{color:"#4CC9F0",fontSize:10,fontFamily:"'DM Mono',monospace",textDecoration:"none",whiteSpace:"nowrap"}}>→ Open</a>}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* AI coach */}
      <div style={{...S.card,borderColor:"rgba(0,245,255,0.15)"}}>
        <div style={{color:"#00F5FF",fontFamily:"'DM Mono',monospace",fontSize:12,fontWeight:"700",marginBottom:10}}>⚡ AI LAUNCH COACH — Tell me where you're stuck</div>
        <input style={{...S.input,flex:"none",width:"100%",marginBottom:12}} placeholder="e.g. 'I've never used GitHub before' or 'I have $50 budget' or 'I want to sell digital prints'…" value={situation} onChange={e=>setSituation(e.target.value)}/>
        <button style={S.btn("#00F5FF")} onClick={()=>run(`You are an Etsy launch coach. Be encouraging, specific, and practical. Plain text only.`,`I'm launching my Etsy shop with EtsyFlow. My situation: "${situation||"brand new, not sure where to start"}". I've completed ${done}/${total} launch checklist items.\n\nTell me:\n1. My single most important next action RIGHT NOW\n2. The fastest path to my first sale (be specific and realistic)\n3. One thing I'm probably overthinking that I should just skip for now\n4. My realistic timeline to first sale\n5. One encouraging fact about where I'm starting from\n\nBe direct, warm, and actionable.`)}>Get My Personalized Launch Plan →</button>
      </div>

      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── PRODUCT SOURCING ──────────────────────────────────────────────────────────

function SourcingPanel() {
  const [niche, setNiche] = useState("");
  const { result, loading, error, run } = useAI();
  return (
    <div>
      <h3 style={S.title}>◈ AI Product Sourcing</h3>
      <p style={S.desc}>Enter a niche → AI finds 8 high-margin, low-competition product opportunities ranked by profit potential.</p>
      <div style={S.row}>
        <input style={S.input} placeholder="e.g. boho home decor, dog lovers, cottagecore, motivational gifts…" value={niche} onChange={e=>setNiche(e.target.value)} onKeyDown={e=>e.key==="Enter"&&run(`You are an expert Etsy product researcher. Find high-margin low-competition products. Clear numbered plain text.`,`Find 8 winning Etsy product ideas in niche: "${niche}". For each: product name, why trending, price range $, competition (Low/Med/High), profit margin %, POD-compatible yes/no. Focus on low competition + growing demand.`)}/>
        <button style={S.btn("#F4A261")} onClick={()=>niche.trim()&&run(`You are an expert Etsy product researcher. Find high-margin low-competition products. Clear numbered plain text.`,`Find 8 winning Etsy product ideas in niche: "${niche}". For each: product name, why trending, price range $, competition (Low/Med/High), profit margin %, POD-compatible yes/no.`)}>Find Products →</button>
      </div>
      {result&&<div style={{marginTop:8,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── LISTING GENERATOR ────────────────────────────────────────────────────────

function ListingsPanel() {
  const [product, setProduct] = useState("");
  const { result, loading, error, run } = useAI();
  return (
    <div>
      <h3 style={S.title}>◉ AI Listing Generator</h3>
      <p style={S.desc}>Enter any product → fully SEO-optimized title, 13 tags, and a converting description. Copy-paste straight into Etsy.</p>
      <div style={S.row}>
        <input style={S.input} placeholder="e.g. personalized wooden cutting board, funny cat tote bag…" value={product} onChange={e=>setProduct(e.target.value)} onKeyDown={e=>e.key==="Enter"&&run(`You are an expert Etsy SEO copywriter. Write titles, tags and descriptions that rank and convert. Plain structured text.`,`Complete Etsy listing for: "${product}". Include: 1)SEO title max 140 chars front-loaded with keywords, 2)13 comma-separated tags (high search volume mix broad+longtail), 3)Description 400-500 words with hook opener, bullet features, keywords naturally, warm CTA, 4)Price recommendation with reasoning, 5)Best category.`)}/>
        <button style={S.btn("#2EC4B6")} onClick={()=>product.trim()&&run(`You are an expert Etsy SEO copywriter. Write titles, tags and descriptions that rank and convert. Plain structured text.`,`Complete Etsy listing for: "${product}". Include: 1)SEO title max 140 chars, 2)13 tags comma-separated, 3)Description 400-500 words, 4)Price recommendation, 5)Category.`)}>Generate Listing →</button>
      </div>
      {result&&<div style={{marginTop:8,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── KEYWORD RESEARCH ─────────────────────────────────────────────────────────

function KeywordsPanel() {
  const [seed, setSeed] = useState(""); const [mode, setMode] = useState("discover");
  const { result, loading, error, run } = useAI();
  const prompts = {
    discover: s=>`Deep keyword research for Etsy: "${s}". Return: 1)TOP 10 SEED KEYWORDS with estimated monthly searches, competition Low/Med/High, buyer intent 1-10. 2)TOP 15 LONG-TAIL KEYWORDS (3-5 words, high buyer intent — these are the gold). 3)TOP 5 TRENDING KEYWORDS (rising right now). 4)KEYWORDS TO AVOID (oversaturated). 5)WINNING TITLE FORMULA using best keywords with example. Be specific and realistic.`,
    gaps: s=>`Find underserved keyword gaps on Etsy for: "${s}" niche. Return: 1)10 UNDERSERVED KEYWORDS (low seller competition, real buyer demand). 2)5 NICHE-DOWN KEYWORDS (ultra-specific, almost no competition). 3)3 EMERGING TRENDS not yet saturated. 4)Single best keyword opportunity nobody's talking about. Feel like insider intelligence.`,
    tags: s=>`Generate perfect 13 Etsy tags for: "${s}". Rules: tags searched exactly as typed, long-tail 2-3 words outperform single words, mix broad+specific, use buyer language. Return: 13 OPTIMIZED TAGS comma-separated ready to paste, REASONING for each tag, 5 BONUS TAGS to rotate if first batch underperforms.`,
  };
  const sys = `You are an Etsy SEO expert with deep knowledge of Etsy's search algorithm. Find high-converting keywords. Be specific, use real Etsy search patterns, plain structured text.`;
  return (
    <div>
      <h3 style={S.title}>⌖ Keyword Research</h3>
      <p style={S.desc}>Find exactly what buyers type into Etsy. High-volume, low-competition keywords that get your listings found and purchased.</p>
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        <Chip label="🔍 Discover Keywords" active={mode==="discover"} color="#4CC9F0" onClick={()=>setMode("discover")}/>
        <Chip label="🎯 Find Gaps" active={mode==="gaps"} color="#4CC9F0" onClick={()=>setMode("gaps")}/>
        <Chip label="🏷 Generate 13 Tags" active={mode==="tags"} color="#4CC9F0" onClick={()=>setMode("tags")}/>
      </div>
      <div style={S.row}>
        <input style={S.input} placeholder="e.g. cottagecore wall art, personalized dog collar, minimalist jewelry…" value={seed} onChange={e=>setSeed(e.target.value)} onKeyDown={e=>e.key==="Enter"&&seed.trim()&&run(sys,prompts[mode](seed))}/>
        <button style={S.btn("#4CC9F0")} onClick={()=>seed.trim()&&run(sys,prompts[mode](seed))}>Research →</button>
      </div>
      {result&&<div style={{marginTop:8,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── MARKETING ENGINE ─────────────────────────────────────────────────────────

function MarketingPanel() {
  const [cat, setCat] = useState(""); const [plat, setPlat] = useState("Pinterest");
  const { result, loading, error, run } = useAI();
  return (
    <div>
      <h3 style={S.title}>◆ Marketing Engine</h3>
      <p style={S.desc}>2-week content plan with captions, hashtags, and posting strategy — fully tailored to your niche and platform.</p>
      <div style={{display:"flex",gap:8,marginBottom:12,flexWrap:"wrap"}}>
        {["Pinterest","Instagram","TikTok","Facebook"].map(p=><Chip key={p} label={p} active={plat===p} color="#E76F51" onClick={()=>setPlat(p)}/>)}
      </div>
      <div style={S.row}>
        <input style={S.input} placeholder="e.g. handmade candles, vintage jewelry, baby shower gifts…" value={cat} onChange={e=>setCat(e.target.value)}/>
        <button style={S.btn("#E76F51")} onClick={()=>cat.trim()&&run(`You are a social media expert driving Etsy traffic. Write content that converts. Plain structured text.`,`2-week ${plat} plan for Etsy shop selling: "${cat}". Include: 10 post titles/captions optimized for ${plat}, best posting times, 5 hashtag sets (10 hashtags each), one viral hook idea, CTA strategy to drive shop visits. Also: 1 email subject line + preview text for 40%+ open rate.`)}>Create Plan →</button>
      </div>
      {result&&<div style={{marginTop:8,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── EMAIL SEQUENCES ──────────────────────────────────────────────────────────

function EmailPanel() {
  const [shopName, setShopName] = useState(""); const [niche, setNiche] = useState(""); const [sequence, setSequence] = useState("welcome");
  const { result, loading, error, run } = useAI();
  const sequences = [
    {id:"welcome",label:"Welcome Series",desc:"New subscriber → buyer (5 emails)"},
    {id:"abandoned",label:"Abandoned Browse",desc:"Viewed but didn't buy (3 emails)"},
    {id:"post_purchase",label:"Post-Purchase",desc:"Turn buyers into repeat customers (3 emails)"},
    {id:"seasonal",label:"Seasonal Campaign",desc:"Holiday push (4 emails)"},
    {id:"review",label:"Review Booster",desc:"Get more 5-star reviews (2 emails)"},
  ];
  const prompts = {
    welcome:`Write a 5-email welcome sequence for${shopName?` "${shopName}"`:""} an Etsy shop selling ${niche||"handmade gifts"}. Email 1 (Immediate): warm welcome + what makes shop special. Email 2 (Day 2): brand story, emotional connection. Email 3 (Day 4): best sellers + social proof. Email 4 (Day 7): exclusive 10% off offer. Email 5 (Day 14): re-engagement + community invite. Each email: SUBJECT LINE (with A/B option), PREVIEW TEXT (40 chars), BODY (150-200 words warm tone), CTA button text.`,
    abandoned:`3-email abandoned browse sequence for${shopName?` "${shopName}"`:""} selling ${niche||"handmade goods"}. Email 1 (1hr): soft reminder, highlight item. Email 2 (24hr): social proof + limited stock urgency. Email 3 (72hr): last chance + free gift wrapping. Each: subject, preview text, 100-150 word body, CTA.`,
    post_purchase:`3-email post-purchase sequence for${shopName?` "${shopName}"`:""} selling ${niche||"handmade gifts"}. Email 1 (Order confirm): excitement + what happens next. Email 2 (After delivery): check-in + subtle review nudge. Email 3 (2 weeks later): repurchase recommendation + offer. Each: subject, preview, 120-180 word body, CTA.`,
    seasonal:`4-email holiday campaign for${shopName?` "${shopName}"`:""} selling ${niche||"handmade gifts"}. Email 1 (6wks out): collection preview. Email 2 (3wks): gift guide with 3-5 products + prices. Email 3 (2wks): last order dates + urgency. Email 4 (Final week): last chance + digital backup option. Each: subject, preview, 150-200 word body, CTA.`,
    review:`2-email review booster for${shopName?` "${shopName}"`:""} selling ${niche||"handmade gifts"}. Email 1 (3 days post-delivery): genuine check-in + soft review ask with instructions. Email 2 (7 days, no review yet): friendly follow-up, mention helping small business. Must feel human not automated. Each: subject, preview, 100-150 word body.`,
  };
  return (
    <div>
      <h3 style={S.title}>✉ Email Sequence Builder</h3>
      <p style={S.desc}>Complete email flows that turn browsers into buyers. Load directly into Mailchimp, Klaviyo, or any email tool.</p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
        <div><label style={S.label}>SHOP NAME (optional)</label><input style={{...S.input,flex:"none",width:"100%"}} placeholder="e.g. MapleCraftCo" value={shopName} onChange={e=>setShopName(e.target.value)}/></div>
        <div><label style={S.label}>YOUR NICHE / PRODUCTS</label><input style={{...S.input,flex:"none",width:"100%"}} placeholder="e.g. personalized jewelry, home decor prints" value={niche} onChange={e=>setNiche(e.target.value)}/></div>
      </div>
      <label style={S.label}>SELECT SEQUENCE TYPE</label>
      <div style={{display:"flex",flexDirection:"column",gap:7,marginBottom:16}}>
        {sequences.map(s=>(
          <button key={s.id} onClick={()=>setSequence(s.id)} style={{background:sequence===s.id?"rgba(247,37,133,0.1)":"rgba(255,255,255,0.03)",border:`1px solid ${sequence===s.id?"#F72585":"rgba(255,255,255,0.07)"}`,borderRadius:10,padding:"11px 16px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{color:sequence===s.id?"#fff":"#888",fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:sequence===s.id?"700":"400"}}>{s.label}</span>
            <span style={{color:"#444",fontFamily:"'DM Mono',monospace",fontSize:11}}>{s.desc}</span>
          </button>
        ))}
      </div>
      <button style={S.btn("#F72585","#fff")} onClick={()=>run(`You are an email marketing expert for Etsy sellers. Write emails that feel personal and drive repeat purchases. Plain structured text with clearly labeled emails.`,prompts[sequence])}>Generate Sequence →</button>
      {result&&<div style={{marginTop:12,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── FULFILLMENT MESSAGES ─────────────────────────────────────────────────────

function FulfillmentPanel() {
  const [sc, setSc] = useState("order_confirm"); const [shop, setShop] = useState("");
  const { result, loading, error, run } = useAI();
  const scenarios = [{id:"order_confirm",l:"Order Confirm"},{id:"shipping",l:"Shipping"},{id:"review_request",l:"Review Ask"},{id:"bad_review",l:"Bad Review"},{id:"custom_issue",l:"Custom Issue"}];
  const labels = {order_confirm:"order confirmation thank-you",shipping:"shipping notification with tracking placeholder",review_request:"delivery confirmation + polite review request",bad_review:"response to a 3-star negative review (professional, empathetic, offers solution)",custom_issue:"response to a customer with a problem on a custom order"};
  return (
    <div>
      <h3 style={S.title}>◎ Fulfillment Messages</h3>
      <p style={S.desc}>Every customer message you'll ever need. Copy, paste, send. Warm and human — never sounds like a bot.</p>
      <input style={{...S.input,flex:"none",width:"100%",marginBottom:12}} placeholder="Your shop name (optional)" value={shop} onChange={e=>setShop(e.target.value)}/>
      <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
        {scenarios.map(s=><Chip key={s.id} label={s.l} active={sc===s.id} color="#A8DADC" onClick={()=>setSc(s.id)}/>)}
      </div>
      <button style={S.btn("#A8DADC")} onClick={()=>run(`You are an Etsy customer service specialist. Write warm professional messages that build loyalty and get 5-star reviews.`,`Write Etsy ${labels[sc]} message${shop?` for shop "${shop}"`:""}. Requirements: warm and human, include [ORDER #] [TRACKING #] [BUYER NAME] placeholders where relevant, under 150 words, memorable closing. Write only the message, copy-paste ready.`)}>Generate Message →</button>
      {result&&<div style={{marginTop:12,display:"flex",justifyContent:"flex-end"}}><CopyBtn text={result}/></div>}
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── ADS CALCULATOR ──────────────────────────────────────────────────────────

function AdsPanel() {
  const [budget,setBudget]=useState("5"); const [cpc,setCpc]=useState("0.35"); const [conv,setConv]=useState("3"); const [aov,setAov]=useState("35");
  const { result, loading, error, run } = useAI();
  const db=parseFloat(budget)||0, cv=parseFloat(cpc)||0.01, cr=parseFloat(conv)||0, ao=parseFloat(aov)||0;
  const clicks=(db/cv).toFixed(0), sales=((clicks*cr)/100).toFixed(1), rev=(sales*ao).toFixed(2), roas=db>0?(rev/db).toFixed(2):0;
  const rc=roas>=3?"#06D6A0":roas>=2?"#FFD166":"#FF6B9D";
  const budgetFor5k = ao>0&&cr>0&&cv>0 ? ((5000/7/ao)*(100/cr)*cv).toFixed(2) : "—";
  return (
    <div>
      <h3 style={S.title}>◑ Etsy Ads Calculator</h3>
      <p style={S.desc}>Model your ad spend vs revenue before spending a dollar. Find the exact budget needed to hit $5K/week.</p>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
        {[["DAILY BUDGET ($)",budget,setBudget],["AVG CPC ($)",cpc,setCpc],["CONV RATE (%)",conv,setConv],["AVG ORDER ($)",aov,setAov]].map(([l,v,s])=>(
          <div key={l}><label style={S.label}>{l}</label><input type="number" style={{...S.input,flex:"none",width:"100%"}} value={v} onChange={e=>s(e.target.value)}/></div>
        ))}
      </div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:16}}>
        <StatCard label="DAILY CLICKS" value={clicks} sub="estimated" color="#FF6B9D"/>
        <StatCard label="DAILY SALES" value={sales} sub="orders" color="#F4A261"/>
        <StatCard label="WEEKLY REV" value={`$${(rev*7).toFixed(0)}`} sub="from ads" color="#2EC4B6"/>
        <StatCard label="ROAS" value={`${roas}x`} sub="return" color={rc}/>
      </div>
      <div style={{...S.card,marginBottom:16,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
        <div><div style={{color:"#888",fontSize:10,fontFamily:"'DM Mono',monospace"}}>MONTHLY PROJECTION</div><div style={{color:"#fff",fontSize:26,fontFamily:"'DM Serif Display',serif"}}>${(rev*30).toFixed(0)}</div></div>
        <div style={{textAlign:"right"}}><div style={{color:"#888",fontSize:10,fontFamily:"'DM Mono',monospace"}}>DAILY BUDGET FOR $5K/WK</div><div style={{color:"#FFD166",fontSize:22,fontFamily:"'DM Serif Display',serif"}}>${budgetFor5k}/day</div></div>
      </div>
      <button style={S.btn("#FF6B9D")} onClick={()=>run(`You are an Etsy Ads expert. Give precise actionable advice. Plain structured text.`,`My Etsy Ads: $${db}/day budget, $${cv} CPC, ${cr}% conv rate, $${ao} AOV, ROAS ${roas}x, daily rev $${rev}. Tell me: 1)Is this ROAS good vs Etsy benchmarks? 2)Which lever to pull first? 3)Keyword bidding strategy for this price point 4)Daily budget needed for $5K/wk target 5)One advanced tactic most sellers miss.`)}>Get AI Ad Strategy →</button>
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── PROFIT TRACKER ──────────────────────────────────────────────────────────

function ProfitPanel() {
  const [products,setProducts]=useState([{id:1,name:"Personalized Mug",price:"28",cost:"8",sales:"12",ads:"15"},{id:2,name:"Custom Tote",price:"22",cost:"6",sales:"8",ads:"8"}]);
  const { result, loading, error, run } = useAI();
  const nid=useRef(3);
  const calc=p=>{const pr=parseFloat(p.price)||0,co=parseFloat(p.cost)||0,sa=parseInt(p.sales)||0,ad=parseFloat(p.ads)||0,fees=pr*0.095+0.20,net=pr-co-fees,profit=(net*sa)-ad;return{net:net.toFixed(2),profit:profit.toFixed(2),margin:pr>0?((net/pr)*100).toFixed(0):0};};
  const twp=products.reduce((s,p)=>s+parseFloat(calc(p).profit||0),0), twr=products.reduce((s,p)=>s+(parseFloat(p.price)||0)*(parseInt(p.sales)||0),0);
  const upd=(id,f,v)=>setProducts(p=>p.map(x=>x.id===id?{...x,[f]:v}:x));
  return (
    <div>
      <h3 style={S.title}>⬡ Profit Tracker</h3>
      <p style={S.desc}>Real margin math after all Etsy fees (6.5% + 3% + $0.20). See true profit and get AI to optimize it.</p>
      <div style={{display:"flex",gap:10,marginBottom:16,flexWrap:"wrap"}}>
        <StatCard label="WEEKLY REVENUE" value={`$${twr.toFixed(0)}`} sub="gross" color="#2EC4B6"/>
        <StatCard label="WEEKLY PROFIT" value={`$${twp.toFixed(0)}`} sub="after all fees" color={twp>0?"#06D6A0":"#FF6B9D"}/>
        <StatCard label="GAP TO $5K/WK" value={`$${Math.max(0,5000-twp).toFixed(0)}`} sub="profit gap" color="#FFD166"/>
      </div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontFamily:"'DM Mono',monospace",fontSize:12}}>
          <thead><tr style={{borderBottom:"1px solid rgba(255,255,255,0.1)"}}>{["PRODUCT","PRICE","COST","SALES/WK","ADS $","MARGIN","PROFIT/WK",""].map(h=><th key={h} style={{padding:"7px 10px",textAlign:"left",color:"#555",fontWeight:"400",whiteSpace:"nowrap"}}>{h}</th>)}</tr></thead>
          <tbody>{products.map(p=>{const c=calc(p);return(
            <tr key={p.id} style={{borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
              <td style={{padding:"7px 10px"}}><input value={p.name} onChange={e=>upd(p.id,"name",e.target.value)} style={{background:"transparent",border:"none",color:"#fff",fontFamily:"'DM Mono',monospace",fontSize:12,width:130,outline:"none"}}/></td>
              {["price","cost","sales","ads"].map(f=><td key={f} style={{padding:"7px 10px"}}><input type="number" value={p[f]} onChange={e=>upd(p.id,f,e.target.value)} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:6,color:"#fff",fontFamily:"'DM Mono',monospace",fontSize:12,width:65,padding:"4px 8px",outline:"none"}}/></td>)}
              <td style={{padding:"7px 10px",color:c.margin>40?"#06D6A0":c.margin>20?"#FFD166":"#FF6B9D"}}>{c.margin}%</td>
              <td style={{padding:"7px 10px",color:parseFloat(c.profit)>0?"#06D6A0":"#FF6B9D",fontWeight:"700"}}>${c.profit}</td>
              <td><button onClick={()=>setProducts(p=>p.filter(x=>x.id!==p.id))} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:14}}>×</button></td>
            </tr>);})}</tbody>
        </table>
      </div>
      <div style={{display:"flex",gap:10,marginTop:12,flexWrap:"wrap"}}>
        <button style={{...S.btn("rgba(255,255,255,0.07)","#ccc"),fontSize:12,padding:"9px 14px"}} onClick={()=>setProducts(p=>[...p,{id:nid.current++,name:"New Product",price:"0",cost:"0",sales:"0",ads:"0"}])}>+ Add Product</button>
        <button style={S.btn("#06D6A0")} onClick={()=>run(`You are a profit optimization expert for Etsy sellers. Plain structured text.`,`Products:\n${products.map(p=>{const c=calc(p);return`${p.name}: $${p.price} price, $${p.cost} cost, ${p.sales}/wk, $${c.profit} profit, ${c.margin}% margin`;}).join("\n")}\nWeekly revenue: $${twr.toFixed(0)}, profit: $${twp.toFixed(0)}\n\nTell me: 1)Best/worst margins and why 2)Prices to raise and how much 3)Costs I can cut 4)Products to drop 5)Specific path to $5K/wk profit from here.`)}>Optimize with AI →</button>
      </div>
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── COMPETITOR ANALYZER ─────────────────────────────────────────────────────

function CompetitorPanel() {
  const [url,setUrl]=useState(""); const [notes,setNotes]=useState(""); const [mode,setMode]=useState("listing");
  const { result, loading, error, run } = useAI();
  return (
    <div>
      <h3 style={S.title}>◭ Competitor Analyzer</h3>
      <p style={S.desc}>Paste a listing URL or shop name. AI finds their weaknesses and gives you a 30-day plan to take their market share.</p>
      <div style={{display:"flex",gap:8,marginBottom:16}}><Chip label="Analyze Listing" active={mode==="listing"} color="#BD93F9" onClick={()=>setMode("listing")}/><Chip label="Analyze Shop" active={mode==="shop"} color="#BD93F9" onClick={()=>setMode("shop")}/></div>
      <input style={{...S.input,flex:"none",width:"100%",marginBottom:10}} placeholder={mode==="listing"?"Etsy listing URL or describe the product…":"Competitor shop name…"} value={url} onChange={e=>setUrl(e.target.value)}/>
      <textarea style={{...S.input,height:70,resize:"vertical",flex:"none",width:"100%",marginBottom:14}} placeholder="Additional notes: price, sales count, review count, anything you noticed…" value={notes} onChange={e=>setNotes(e.target.value)}/>
      <button style={S.btn("#BD93F9")} onClick={()=>run(`You are a ruthless Etsy competitive intelligence expert. Find weaknesses and opportunities. Plain structured text.`,mode==="listing"?`Competitor listing: "${url||"not provided"}" Notes: "${notes||"none"}". Analyze: 1)Keywords they target + gaps to exploit 2)Pricing opportunity 3)Photo weaknesses 4)Description gaps 5)Common review complaints 6)My winning angle 7)One thing to do TODAY to outrank them.`:`Competitor shop${url?` "${url}"`:""}. Notes: "${notes||"general competitor"}". Teardown: 1)Their strengths 2)Vulnerabilities 3)Keyword gaps 4)Pricing opportunity 5)Product gaps 6)30-day plan to steal market share 7)One thing to copy immediately.`)}>Run Analysis →</button>
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── SEASONAL CALENDAR ────────────────────────────────────────────────────────

function SeasonalPanel() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [niche, setNiche] = useState("");
  const { result, loading, error, run } = useAI();
  const month = SEASONS[selectedMonth];
  return (
    <div>
      <h3 style={S.title}>❋ Seasonal Trend Calendar</h3>
      <p style={S.desc}>Etsy sellers who prepare 6 weeks early capture 3x more seasonal sales. Pick a month, get your full action plan.</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:6,marginBottom:16}}>
        {SEASONS.map((s,i)=>(
          <button key={i} onClick={()=>{setSelectedMonth(i);}} style={{padding:"10px 6px",borderRadius:10,cursor:"pointer",textAlign:"center",border:`1px solid ${selectedMonth===i?"#FF9A3C":"rgba(255,255,255,0.07)"}`,background:selectedMonth===i?"rgba(255,154,60,0.14)":"rgba(255,255,255,0.02)"}}>
            <div style={{fontSize:18,marginBottom:3}}>{s.icon}</div>
            <div style={{color:selectedMonth===i?"#FF9A3C":"#555",fontSize:10,fontFamily:"'DM Mono',monospace",fontWeight:selectedMonth===i?"700":"400"}}>{s.month.slice(0,3).toUpperCase()}</div>
          </button>
        ))}
      </div>
      <div style={{...S.card,marginBottom:16,borderColor:"rgba(255,154,60,0.2)"}}>
        <div style={{color:"#FF9A3C",fontSize:15,fontFamily:"'DM Serif Display',serif",marginBottom:8}}>{month.icon} {month.month}</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:8}}>{month.events.map(e=><span key={e} style={{padding:"3px 10px",borderRadius:20,background:"rgba(255,154,60,0.12)",border:"1px solid rgba(255,154,60,0.25)",color:"#FF9A3C",fontSize:11,fontFamily:"'DM Mono',monospace"}}>{e}</span>)}</div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{month.niches.map(n=><span key={n} style={{padding:"2px 9px",borderRadius:20,background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",color:"#888",fontSize:11,fontFamily:"'DM Mono',monospace"}}>{n}</span>)}</div>
      </div>
      <div style={S.row}>
        <input style={S.input} placeholder="Your niche (optional): e.g. candles, personalized gifts, printables…" value={niche} onChange={e=>setNiche(e.target.value)}/>
        <button style={S.btn("#FF9A3C")} onClick={()=>run(`You are an Etsy seasonal trend expert. Help sellers prepare 6-8 weeks in advance. Plain structured text.`,`Seasonal action plan for ${month.month} on Etsy${niche?` for shop selling ${niche}`:""}.Key events: ${month.events.join(", ")}. Include: 1)TIMELINE when to list (weeks before each event) 2)TOP 5 PRODUCT IDEAS with price recs 3)KEYWORD STRATEGY for ${month.month} 4)LISTING REFRESH for existing products 5)MARKETING CALENDAR for the month 6)WHAT TO PREPARE NOW for next month 7)REVENUE OPPORTUNITY SCORE 1-10 and why.`)}>Get {month.month} Plan →</button>
      </div>
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── SCALE ADVISOR ────────────────────────────────────────────────────────────

function ScalePanel() {
  const [data, setData] = useState("");
  const { result, loading, error, run } = useAI();
  return (
    <div>
      <h3 style={S.title}>▲ Scale Advisor</h3>
      <p style={S.desc}>Tell AI exactly where you're at — sales, products, challenges. Get a laser-focused plan to reach $5K/week.</p>
      <textarea style={{...S.input,height:100,resize:"vertical",flex:"none",width:"100%",marginBottom:12}} placeholder="Describe your situation: weekly sales, number of listings, what's working, what's not, your budget…" value={data} onChange={e=>setData(e.target.value)}/>
      <button style={S.btn("#FFD166")} onClick={()=>run(`You are a seasoned Etsy growth strategist who has helped 100+ sellers reach $10K+/month. Give blunt data-driven actionable advice. No fluff.`,`My shop: "${data||"New shop, 0 sales, home decor niche"}"\n\nGive me: 1)3 IMMEDIATE ACTIONS this week 2)BIGGEST LEVER to pull right now (single focus) 3)Products to add or drop 4)Ads strategy with specific budget 5)Revenue math to $5K/week in 90 days from my current position 6)One unconventional tactic most sellers overlook. Be direct.`)}>Get Scale Strategy →</button>
      <ResultBox result={result} loading={loading} error={error}/>
    </div>
  );
}

// ─── $5K ROADMAP ──────────────────────────────────────────────────────────────

function RoadmapPanel() {
  const sc={start:"#2EC4B6",build:"#F4A261",grow:"#E76F51",scale:"#FFD166",peak:"#C77DFF"};
  const sl={start:"LAUNCH",build:"BUILD",grow:"GROW",scale:"SCALE",peak:"PEAK"};
  return (
    <div>
      <h3 style={S.title}>◐ $5K/Week Roadmap</h3>
      <p style={S.desc}>Your 12-week path from $0 to $5,000/week. Follow each phase with the tools in this dashboard.</p>
      <div style={{display:"flex",flexDirection:"column",gap:10,marginTop:8}}>
        {ROADMAP_DATA.map((r,i)=>(
          <div key={i} style={{display:"flex",gap:14,alignItems:"flex-start",background:"rgba(255,255,255,0.02)",border:`1px solid ${sc[r.status]}20`,borderLeft:`3px solid ${sc[r.status]}`,borderRadius:9,padding:"14px 16px"}}>
            <div style={{minWidth:56}}><div style={{background:sc[r.status],color:"#0d0d0d",borderRadius:5,padding:"3px 7px",fontSize:10,fontWeight:"700",fontFamily:"'DM Mono',monospace",textAlign:"center"}}>{sl[r.status]}</div></div>
            <div style={{flex:1}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5,flexWrap:"wrap",gap:6}}>
                <span style={{color:"#fff",fontFamily:"'DM Mono',monospace",fontSize:12,fontWeight:"700"}}>{r.week}</span>
                <span style={{color:sc[r.status],fontFamily:"'DM Serif Display',serif",fontSize:14}}>{r.goal}</span>
              </div>
              <p style={{margin:0,color:"#888",fontSize:12,fontFamily:"'DM Mono',monospace",lineHeight:1.5}}>{r.action}</p>
            </div>
          </div>
        ))}
      </div>
      <div style={{...S.card,marginTop:20,background:"linear-gradient(135deg,rgba(196,125,255,0.07),rgba(244,162,97,0.07))",border:"1px solid rgba(196,125,255,0.15)"}}>
        <div style={{fontFamily:"'DM Serif Display',serif",fontSize:16,color:"#fff",marginBottom:8}}>⚡ The Core Formula</div>
        <div style={{fontFamily:"'DM Mono',monospace",fontSize:12,color:"#ccc",lineHeight:2.2}}>
          <span style={{color:"#F4A261"}}>10 listings</span> × $40 avg × <span style={{color:"#2EC4B6"}}>3 sales/day each</span> = <span style={{color:"#FFD166"}}>$1,200/day → $8,400/week</span>
          <div style={{color:"#555",fontSize:11,marginTop:4}}>You only need 3–5 winners converting once/day to hit $5K/wk. Use Ads + Competitor tools to find them, then pour fuel on them.</div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function Home() {
  const [active, setActive]           = useState("launch");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const panels = {
    launch:<LaunchPanel/>, sourcing:<SourcingPanel/>, listings:<ListingsPanel/>,
    keywords:<KeywordsPanel/>, marketing:<MarketingPanel/>, email:<EmailPanel/>,
    fulfillment:<FulfillmentPanel/>, ads:<AdsPanel/>, profit:<ProfitPanel/>,
    competitor:<CompetitorPanel/>, seasonal:<SeasonalPanel/>, scale:<ScalePanel/>,
    roadmap:<RoadmapPanel/>,
  };

  const currentMod = MODULES.find(m=>m.id===active);
  const groups = [...new Set(MODULES.map(m=>m.group))];

  return (
    <div style={{display:"flex",height:"100vh",background:"#0d0d0d",overflow:"hidden"}}>

      {/* SIDEBAR */}
      <div style={{width:sidebarOpen?"230px":"54px",minWidth:sidebarOpen?"230px":"54px",background:"rgba(255,255,255,0.02)",borderRight:"1px solid rgba(255,255,255,0.06)",display:"flex",flexDirection:"column",transition:"all 0.25s ease",overflow:"hidden"}}>

        <div style={{padding:sidebarOpen?"20px 16px 12px":"20px 10px 12px",borderBottom:"1px solid rgba(255,255,255,0.06)"}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:28,height:28,borderRadius:7,background:"linear-gradient(135deg,#F4A261,#E76F51)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>◈</div>
            {sidebarOpen&&<div style={{animation:"fadeUp 0.25s ease"}}>
              <div style={{color:"#fff",fontSize:13,fontWeight:"700",fontFamily:"'DM Mono',monospace",letterSpacing:"0.5px"}}>ETSYFLOW</div>
              <div style={{color:"#333",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"1.5px",marginTop:1}}>AI AUTOMATION v3</div>
            </div>}
          </div>
        </div>

        {sidebarOpen&&(
          <div style={{padding:"8px 16px",borderBottom:"1px solid rgba(255,255,255,0.06)",display:"flex",alignItems:"center",gap:8}}>
            <div style={{width:5,height:5,borderRadius:"50%",background:"#06D6A0",animation:"pulse 2s infinite"}}/>
            <span style={{color:"#06D6A0",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"1px"}}>CLAUDE AI · 13 MODULES</span>
          </div>
        )}

        <div style={{flex:1,padding:sidebarOpen?"12px 8px":"10px 5px",overflowY:"auto"}}>
          {groups.map(group=>(
            <div key={group}>
              {sidebarOpen&&<div style={{color:"#282828",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"1.5px",padding:"10px 8px 5px"}}>{group}</div>}
              {MODULES.filter(m=>m.group===group).map(mod=>(
                <button key={mod.id} onClick={()=>setActive(mod.id)} style={{background:active===mod.id?`${mod.color}14`:"transparent",border:`1px solid ${active===mod.id?`${mod.color}35`:"transparent"}`,borderRadius:8,padding:sidebarOpen?"8px 10px":"8px",cursor:"pointer",display:"flex",alignItems:"center",gap:8,transition:"all 0.1s",justifyContent:sidebarOpen?"flex-start":"center",width:"100%",marginBottom:2}}>
                  <span style={{fontSize:14,color:active===mod.id?mod.color:"#444",flexShrink:0}}>{mod.icon}</span>
                  {sidebarOpen&&<span style={{color:active===mod.id?"#fff":"#555",fontSize:11,fontWeight:active===mod.id?"700":"400",whiteSpace:"nowrap",fontFamily:"'DM Mono',monospace",flex:1}}>{mod.label}</span>}
                  {sidebarOpen&&mod.id==="launch"&&<span style={{background:"#00F5FF",color:"#0d0d0d",fontSize:8,padding:"1px 5px",borderRadius:6,fontWeight:"700",fontFamily:"'DM Mono',monospace"}}>START</span>}
                </button>
              ))}
            </div>
          ))}
        </div>

        <button onClick={()=>setSidebarOpen(!sidebarOpen)} style={{margin:"0 8px 12px",background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:7,padding:7,cursor:"pointer",color:"#444",fontSize:11,fontFamily:"'DM Mono',monospace"}}>
          {sidebarOpen?"← Collapse":"→"}
        </button>
      </div>

      {/* MAIN CONTENT */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>

        <div style={{padding:"13px 26px",borderBottom:"1px solid rgba(255,255,255,0.05)",display:"flex",alignItems:"center",justifyContent:"space-between",background:"rgba(255,255,255,0.01)"}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            {currentMod&&<span style={{color:currentMod.color,fontSize:14}}>{currentMod.icon}</span>}
            <span style={{color:"#444",fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:"1px"}}>{currentMod?.label?.toUpperCase()}</span>
          </div>
          <div style={{display:"flex",gap:14,alignItems:"center"}}>
            <span style={{color:"#333",fontSize:10,fontFamily:"'DM Mono',monospace"}}>GOAL: <span style={{color:"#FFD166"}}>$5,000/WEEK</span></span>
            <div style={{background:"rgba(6,214,160,0.08)",border:"1px solid rgba(6,214,160,0.2)",borderRadius:20,padding:"3px 12px",color:"#06D6A0",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"0.5px"}}>● LIVE</div>
          </div>
        </div>

        <div style={{flex:1,overflowY:"auto",padding:"28px 32px",animation:"fadeUp 0.25s ease"}}>
          <div style={{maxWidth:820}}>{panels[active]}</div>
        </div>

        <div style={{padding:"8px 26px",borderTop:"1px solid rgba(255,255,255,0.04)",display:"flex",gap:18,overflowX:"auto"}}>
          {["⚡ Start: Launch","① Source","② Keywords","③ List","④ Market","⑤ Email","⑥ Fulfill","⑦ Ads","⑧ Profit","⑨ Spy","⑩ Seasonal","⑪ Scale","⑫ $5K"].map((s,i)=>(
            <div key={i} style={{color:"#252525",fontSize:10,whiteSpace:"nowrap",fontFamily:"'DM Mono',monospace"}}>{s}</div>
          ))}
        </div>
      </div>
    </div>
  );
}
